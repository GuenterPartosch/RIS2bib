# corr.py
# used with the parameter -c

config["UNPB"]["SN"]   = "isbn"         # IDBN/ISSN
config["UNPB"]["U3"]   = "note"         # Notice
